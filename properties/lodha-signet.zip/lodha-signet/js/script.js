Fancybox.bind("[data-fancybox]", {
    // Custom options for the first gallery
});

// popup function 
// $(window).ready (function () {
// 	setTimeout (function () {
// 		$ ('#popupModal').modal ("show")
// 	}, 3000)
// })
